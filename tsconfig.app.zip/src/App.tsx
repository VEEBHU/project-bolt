import React from 'react';
import Header from './components/Header';
import Stories from './components/Stories';
import Post from './components/Post';
import Suggestions from './components/Suggestions';

function App() {
  const posts = [
    {
      id: 1,
      username: "johndoe",
      userImage: "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?ixlib=rb-1.2.1&auto=format&fit=crop&w=80&q=80",
      image: "https://images.unsplash.com/photo-1682687220742-aba13b6e50ba?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80",
      caption: "Beautiful sunset at the beach! 🌅",
      likes: 123,
      timestamp: "2024-03-10T12:00:00Z",
      comments: [
        {
          id: 1,
          username: "janedoe",
          text: "Amazing shot! 😍",
          timestamp: "2024-03-10T12:30:00Z"
        }
      ]
    },
    {
      id: 2,
      username: "janedoe",
      userImage: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-1.2.1&auto=format&fit=crop&w=80&q=80",
      image: "https://images.unsplash.com/photo-1682687221038-404670f09ef7?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80",
      caption: "Coffee and code ☕️💻",
      likes: 456,
      timestamp: "2024-03-10T11:00:00Z",
      comments: [
        {
          id: 1,
          username: "techie",
          text: "Perfect combo!",
          timestamp: "2024-03-10T11:15:00Z"
        }
      ]
    }
  ];

  return (
    <div className="bg-gray-50 min-h-screen">
      <Header />
      
      <main className="max-w-6xl mx-auto grid grid-cols-1 md:grid-cols-3 md:gap-8 p-4 md:p-6">
        <section className="col-span-2">
          <Stories />
          
          <div className="mt-6">
            {posts.map(post => (
              <Post key={post.id} post={post} />
            ))}
          </div>
        </section>

        <section className="hidden md:block">
          <div className="fixed w-[380px]">
            <div className="flex items-center space-x-4 mt-8">
              <img
                src="https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?ixlib=rb-1.2.1&auto=format&fit=crop&w=80&q=80"
                alt="Your profile"
                className="h-14 w-14 rounded-full border p-[2px]"
              />
              <div>
                <h2 className="font-bold">johndoe</h2>
                <h3 className="text-sm text-gray-400">John Doe</h3>
              </div>
              <button className="text-blue-400 text-sm font-semibold ml-auto">
                Switch
              </button>
            </div>

            <Suggestions />
          </div>
        </section>
      </main>
    </div>
  );
}

export default App;