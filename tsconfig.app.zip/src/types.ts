export interface Post {
  id: number;
  username: string;
  userImage: string;
  image: string;
  caption: string;
  likes: number;
  timestamp: string;
  comments: Comment[];
}

export interface Comment {
  id: number;
  username: string;
  text: string;
  timestamp: string;
}