import { Camera, Heart, MessageCircle, Search } from 'lucide-react';

export default function Header() {
  return (
    <header className="sticky top-0 z-50 bg-white border-b shadow-sm">
      <div className="flex justify-between items-center max-w-6xl mx-auto p-4">
        <div className="text-2xl font-bold cursor-pointer bg-gradient-to-r from-purple-600 to-blue-500 text-transparent bg-clip-text">PLATORA.IO</div>
        
        <div className="hidden sm:flex items-center bg-gray-100 rounded-lg p-2">
          <Search className="h-5 w-5 text-gray-500" />
          <input
            type="text"
            placeholder="Search"
            className="bg-transparent outline-none ml-2"
          />
        </div>
        
        <div className="flex items-center space-x-4">
          <Camera className="navBtn" />
          <Heart className="navBtn" />
          <MessageCircle className="navBtn" />
          <img
            src="https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?ixlib=rb-1.2.1&auto=format&fit=crop&w=80&q=80"
            alt="Profile"
            className="h-8 w-8 rounded-full cursor-pointer"
          />
        </div>
      </div>
    </header>
  );
}