import { useState } from 'react';
import { formatDistanceToNow } from 'date-fns';
import { Heart, MessageCircle, Send, Bookmark, MoreHorizontal } from 'lucide-react';
import type { Post as PostType } from '../types';

interface PostProps {
  post: PostType;
}

export default function Post({ post }: PostProps) {
  const [isLiked, setIsLiked] = useState(false);
  const [showComments, setShowComments] = useState(false);

  return (
    <div className="bg-white border rounded-lg mb-6">
      <div className="flex items-center p-4">
        <img
          src={post.userImage}
          alt={post.username}
          className="h-10 w-10 rounded-full object-cover mr-3"
        />
        <p className="flex-1 font-semibold">{post.username}</p>
        <MoreHorizontal className="h-5 cursor-pointer" />
      </div>

      <img src={post.image} alt="" className="w-full object-cover" />

      <div className="p-4">
        <div className="flex justify-between mb-4">
          <div className="flex space-x-4">
            <Heart
              className={`h-6 w-6 cursor-pointer ${isLiked ? 'fill-red-500 text-red-500' : ''}`}
              onClick={() => setIsLiked(!isLiked)}
            />
            <MessageCircle
              className="h-6 w-6 cursor-pointer"
              onClick={() => setShowComments(!showComments)}
            />
            <Send className="h-6 w-6 cursor-pointer" />
          </div>
          <Bookmark className="h-6 w-6 cursor-pointer" />
        </div>

        <p className="font-semibold mb-1">{post.likes} likes</p>
        
        <div className="space-y-2">
          <p>
            <span className="font-semibold mr-2">{post.username}</span>
            {post.caption}
          </p>
          
          {showComments && post.comments.map(comment => (
            <p key={comment.id}>
              <span className="font-semibold mr-2">{comment.username}</span>
              {comment.text}
            </p>
          ))}
        </div>

        <p className="text-gray-400 text-xs mt-2">
          {formatDistanceToNow(new Date(post.timestamp))} ago
        </p>
      </div>

      <div className="border-t p-4">
        <div className="flex items-center">
          <input
            type="text"
            placeholder="Add a comment..."
            className="flex-1 outline-none"
          />
          <button className="text-blue-500 font-semibold">Post</button>
        </div>
      </div>
    </div>
  );
}