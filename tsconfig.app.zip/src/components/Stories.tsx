export default function Stories() {
  const stories = [
    {
      id: 1,
      username: "johndoe",
      image: "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?ixlib=rb-1.2.1&auto=format&fit=crop&w=80&q=80"
    },
    {
      id: 2,
      username: "janedoe",
      image: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-1.2.1&auto=format&fit=crop&w=80&q=80"
    },
    {
      id: 3,
      username: "alexsmith",
      image: "https://images.unsplash.com/photo-1527980965255-d3b416303d12?ixlib=rb-1.2.1&auto=format&fit=crop&w=80&q=80"
    },
    // Add more stories as needed
  ];

  return (
    <div className="flex space-x-4 p-6 bg-white border rounded-lg overflow-x-scroll scrollbar-none">
      {stories.map(story => (
        <div key={story.id} className="flex flex-col items-center space-y-1">
          <div className="bg-gradient-to-tr from-yellow-400 to-pink-600 p-[2px] rounded-full">
            <div className="bg-white p-[2px] rounded-full">
              <img
                src={story.image}
                alt={story.username}
                className="h-14 w-14 rounded-full object-cover cursor-pointer"
              />
            </div>
          </div>
          <p className="text-xs w-14 truncate text-center">{story.username}</p>
        </div>
      ))}
    </div>
  );
}