export default function Suggestions() {
  const suggestions = [
    {
      id: 1,
      username: "tech.tips",
      image: "https://images.unsplash.com/photo-1531427186611-ecfd6d936c79?ixlib=rb-1.2.1&auto=format&fit=crop&w=80&q=80",
      description: "Followed by user1 + 2 more"
    },
    {
      id: 2,
      username: "travel.photos",
      image: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?ixlib=rb-1.2.1&auto=format&fit=crop&w=80&q=80",
      description: "Followed by user2 + 3 more"
    },
    // Add more suggestions as needed
  ];

  return (
    <div className="mt-4">
      <div className="flex justify-between mb-5">
        <h3 className="text-sm font-semibold text-gray-400">Suggestions For You</h3>
        <button className="text-sm font-semibold">See All</button>
      </div>

      {suggestions.map(suggestion => (
        <div key={suggestion.id} className="flex items-center justify-between mt-3">
          <div className="flex items-center">
            <img
              src={suggestion.image}
              alt={suggestion.username}
              className="w-8 h-8 rounded-full border p-[2px]"
            />
            <div className="ml-4">
              <h2 className="text-sm font-semibold">{suggestion.username}</h2>
              <h3 className="text-xs text-gray-400">{suggestion.description}</h3>
            </div>
          </div>
          <button className="text-xs font-semibold text-blue-400">Follow</button>
        </div>
      ))}
    </div>
  );
}